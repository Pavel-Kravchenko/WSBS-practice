args <- commandArgs(trailingOnly = T)

name_plot <- toString(args[4])

"%+%" <- function(...){
  paste0(...)
}

name_plot0.0 <- name_plot %+% "/LD.txt"

LD_txt <- read.csv(name_plot0.0, sep = '\t', 
                   stringsAsFactors = F)
LD_txt <- LD_txt[order(LD_txt$Len, decreasing = F),] 
x <- LD_txt$Len
y <- LD_txt$LD

df1 <- data.frame(x, y)
if (length(df1$x) > 100000) { df1 <- df1[1:100000,]}
#if (length(df1$x) > 50000) {df1 <- df1[sample(nrow(df1), 50000), ]}
cor.test(as.integer(df1$y), as.integer(df1$x), method = "kendall")
